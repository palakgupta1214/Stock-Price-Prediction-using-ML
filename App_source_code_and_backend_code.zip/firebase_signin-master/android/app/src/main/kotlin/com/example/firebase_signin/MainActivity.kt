package com.example.firebase_signin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
